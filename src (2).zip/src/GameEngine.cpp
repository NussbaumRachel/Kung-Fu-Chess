#include "GameEngine.hpp"
#include "Piece.hpp"
#include "PieceFactory.hpp"
#include <cstdlib>

GameEngine::GameEngine(Board board)
    : board_(std::move(board))
{
}

const Board& GameEngine::getBoard() const
{
    return board_;
}

GameState GameEngine::getState() const
{
    return state_;
}

void GameEngine::handleCellClick(int row, int col)
{
    if (state_ == GameState::GAME_OVER)
        return;

    if (!board_.isInsideBoard(row, col))
        return;

    // --- WAITING_SELECTION ---
    if (state_ == GameState::WAITING_SELECTION)
    {
        if (!board_.isEmptyCell(row, col) &&
            !isPieceAtPositionInvolved(row, col))
        {
            selectedCell_ = Position{row, col};
            state_ = GameState::WAITING_TARGET;
        }
        return;
    }

    // --- WAITING_TARGET ---
    if (state_ == GameState::WAITING_TARGET)
    {
        // בדיקה שהכלי הנבחר עדיין קיים
        if (!selectedCell_.has_value() ||
            board_.isEmptyCell(selectedCell_->row, selectedCell_->col))
        {
            selectedCell_ = std::nullopt;
            state_ = GameState::WAITING_SELECTION;
            return;
        }

        Piece* selectedPiece = board_.getCell(selectedCell_->row, selectedCell_->col);

        // ── קפיצה: לחיצה על אותו תא ──
        if (Position{row, col} == *selectedCell_)
        {
            // בודק שהכלי לא בתנועה ושלא נלכד
            if (isPieceAtPositionInvolved(row, col))
                return;

            arbiter_.startJump(selectedPiece, *selectedCell_, JUMP_DURATION_MS);
            selectedPiece->setState(PieceState::Jumping);
            selectedCell_ = std::nullopt;
            state_ = GameState::JUMP_IN_PROGRESS;
            return;
        }

        // לחיצה על כלי ידידותי אחר — מחליף בחירה
        if (!board_.isEmptyCell(row, col))
        {
            Piece* targetPiece = board_.getCell(row, col);

            if (targetPiece->getColor() == selectedPiece->getColor())
            {
                if (!isPieceAtPositionInvolved(row, col))
                {
                    selectedCell_ = Position{row, col};
                }
                return;
            }
        }

        // בדיקת חוקיות דרך RuleEngine
        Color playerColor = selectedPiece->getColor();

        MoveValidation validation = ruleEngine_.validateMove(
            board_, *selectedCell_, Position{row, col}, playerColor);

        if (!validation.isValid)
        {
            selectedCell_ = std::nullopt;
            state_ = GameState::WAITING_SELECTION;
            return;
        }

        // התחלת תנועה
        int duration = calculateMoveTime(
            selectedCell_->row, selectedCell_->col, row, col);

        arbiter_.startMove(selectedPiece, *selectedCell_, Position{row, col}, duration);
        selectedPiece->setState(PieceState::Moving);
        selectedCell_ = std::nullopt;
        state_ = GameState::MOVE_IN_PROGRESS;

        if (!arbiter_.hasActiveMoves())
            state_ = GameState::WAITING_SELECTION;

        return;
    }

    // --- MOVE_IN_PROGRESS / JUMP_IN_PROGRESS ---
    // לא ניתן לבחור כלי בזמן שתנועה או קפיצה פעילה
    return;
}

void GameEngine::advanceTime(int milliseconds)
{
    arbiter_.advanceTime(milliseconds);

    // ── טיפול ב-Jumps שהושלמו ──
    auto completedJumps = arbiter_.pollCompletedJumps();
    for (const auto& jump : completedJumps)
    {
        if (jump.piece)
            jump.piece->setState(PieceState::Idle);
    }

    // ── טיפול ב-Moves שהושלמו ──
    auto completedMoves = arbiter_.pollCompletedMoves();

    // בודק יירוטים: moves שבוטלו (wasCancelled=true) כאשר קופץ יירט אותם
    for (const CompletedMove& cm : completedMoves)
    {
        if (cm.wasCancelled && cm.piece)
        {
            // בודק אם האויב בוטל ע"י יירוט קפיצה
            // ב-Arbiter, resolveJumpInterceptions() קראה ל-move.cancel()
            // האויב המבוטל — הקופץ לוכד אותו
            cm.piece->setState(PieceState::Captured);
            delete board_.takeCell(cm.from.row, cm.from.col);
            // הקופץ נשאר במקום — ממשיכים
            continue;
        }

        applyCompletedMove(cm);
        if (state_ == GameState::GAME_OVER)
            return;
    }

    // ── חזרה למצב בחירה ──
    bool allDone = !arbiter_.hasActiveMoves() && !arbiter_.hasActiveJumps();
    if (allDone && (state_ == GameState::MOVE_IN_PROGRESS || state_ == GameState::JUMP_IN_PROGRESS))
    {
        state_ = GameState::WAITING_SELECTION;
    }
}

GameSnapshot GameEngine::getSnapshot() const
{
    GameSnapshot snapshot;
    snapshot.boardWidth = board_.colCount();
    snapshot.boardHeight = board_.rowCount();
    snapshot.selectedCell = selectedCell_;
    snapshot.gameOver = (state_ == GameState::GAME_OVER);

    const auto& grid = board_.getGrid();
    for (int r = 0; r < board_.rowCount(); ++r)
    {
        for (int c = 0; c < board_.colCount(); ++c)
        {
            Piece* p = grid[r][c];
            if (p)
            {
                PieceInfo info;
                info.kind = p->getType();
                info.color = p->getColor();
                info.pieceId = p->getId();
                info.cell = p->getCell();
                info.state = p->getState();
                info.progress = 0.0;

                if (p->getState() == PieceState::Moving)
                {
                    for (const Move& move : arbiter_.getActiveMoves())
                    {
                        if (move.getPiece() == p)
                        {
                            info.progress = move.getProgress();
                            break;
                        }
                    }
                }
                else if (p->getState() == PieceState::Jumping)
                {
                    for (const JumpEntry& jump : arbiter_.getActiveJumps())
                    {
                        if (jump.piece == p)
                        {
                            info.progress = 1.0 -
                                static_cast<double>(jump.remainingMs) / JUMP_DURATION_MS;
                            break;
                        }
                    }
                }

                snapshot.pieces.push_back(info);
            }
        }
    }

    snapshot.winner = winner_;
    return snapshot;
}

bool GameEngine::isPieceAtPositionInvolved(int row, int col) const
{
    return arbiter_.isCellInvolved(row, col);
}

int GameEngine::calculateMoveTime(int fromRow, int fromCol,
                                   int toRow, int toCol) const
{
    int distance = std::abs(toRow - fromRow) + std::abs(toCol - fromCol);
    return distance * 1000;
}

void GameEngine::applyCompletedMove(const CompletedMove& cm)
{
    if (cm.wasCancelled)
    {
        if (cm.piece)
            cm.piece->setState(PieceState::Idle);
        return;
    }

    Piece* piece = board_.takeCell(cm.from.row, cm.from.col);
    if (!piece)
        piece = cm.piece;

    Piece* targetPiece = board_.getCell(cm.to.row, cm.to.col);
    if (targetPiece)
    {
        if (targetPiece->getType() == PieceType::King)
        {
            targetPiece->setState(PieceState::Captured);
            delete board_.takeCell(cm.to.row, cm.to.col);
            board_.setCell(cm.to.row, cm.to.col, piece);
            piece->setCell(cm.to);
            piece->setState(PieceState::Idle);
            state_ = GameState::GAME_OVER;
            winner_ = piece->getColor();
            return;
        }

        targetPiece->setState(PieceState::Captured);
        delete board_.takeCell(cm.to.row, cm.to.col);
    }

    board_.setCell(cm.to.row, cm.to.col, piece);
    piece->setCell(cm.to);
    piece->setState(PieceState::Idle);

    int lastRow = (piece->getColor() == Color::White) ? 0 : board_.rowCount() - 1;
    if (piece->getType() == PieceType::Pawn && cm.to.row == lastRow)
    {
        promotePawn(piece, cm.to);
    }
}

void GameEngine::promotePawn(Piece* pawn, Position at)
{
    Color pawnColor = pawn->getColor();
    delete board_.takeCell(at.row, at.col);

    std::string token;
    token += (pawnColor == Color::White) ? 'w' : 'b';
    token += 'Q';

    Piece* queen = PieceFactory::createFromToken(token, at);
    board_.setCell(at.row, at.col, queen);
}
